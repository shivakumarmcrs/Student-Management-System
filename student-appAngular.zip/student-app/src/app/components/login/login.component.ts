import { Component } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'] 
})
export class LoginComponent {

  model = { username: '', password: '' };

  constructor(private auth: AuthService, private router: Router) {}

  login() {
     if (!this.model.username || !this.model.password) {
    alert('Please enter username and password');
    return;
  }

  this.auth.login(this.model).subscribe(
    (res: any) => {
      this.auth.saveToken(res.token);
      this.router.navigate(['/students']);
    },
    err => {
      alert('Invalid login');
    }
  );
}
}