import { Component } from '@angular/core';
import { StudentService } from 'src/app/services/student.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent {

  model: any = {};
  isEdit = false;

  errors: any = {}; 

  constructor(
    private service: StudentService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.isEdit = true;

      this.service.getById(+id).subscribe((res: any) => {
        this.model = res; 
      });
    }
  }

  
  validate(): boolean {
    this.errors = {};

    if (!this.model.name) {
      this.errors.name = 'Name is required';
    }

    if (!this.model.email) {
      this.errors.email = 'Email is required';
    } else if (!this.model.email.includes('@')) {
      this.errors.email = 'Enter valid email';
    }

    if (!this.model.age) {
      this.errors.age = 'Age is required';
    } else if (this.model.age < 1 || this.model.age > 100) {
      this.errors.age = 'Age must be between 1 and 100';
    }

    if (!this.model.course) {
      this.errors.course = 'Course is required';
    }

    return Object.keys(this.errors).length === 0;
  }

  
  save() {

    if (!this.validate()) {
      return; 
    }

    if (this.isEdit) {
      this.service.update(this.model).subscribe(() => {
        this.router.navigate(['/students']);
      });
    } else {
      this.service.add(this.model).subscribe(() => {
        this.router.navigate(['/students']);
      });
    }
  }

  goBack() {
    this.router.navigate(['/students']);
  }
}