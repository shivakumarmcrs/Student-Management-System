import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/services/student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css'] 
})
export class StudentListComponent implements OnInit {

  students: any[] = [];

  constructor(private service: StudentService,private router: Router) {}

  ngOnInit() {
    this.load();
  }

  load() {
    this.service.getAll().subscribe((res: any) => {
      this.students = res;
    });
  }
  edit(id: number) {
  this.router.navigate(['/edit', id]);
  }

  delete(id: number) {
    if (confirm('Delete?')) {
      this.service.delete(id).subscribe(() => {
        this.load();
      });
    }
  }
  
}