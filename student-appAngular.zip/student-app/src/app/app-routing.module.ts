import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './components/login/login.component';
import { StudentListComponent } from './components/student-list/student-list.component';
import { StudentFormComponent } from './components/student-form/student-form.component';
import { AuthGuard } from './guards/auth.guard';
const routes: Routes = [{ path: '', component: LoginComponent },
  { path: 'students', component: StudentListComponent, canActivate: [AuthGuard] },
  { path: 'add', component: StudentFormComponent, canActivate: [AuthGuard] },
  { path: 'edit/:id', component: StudentFormComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
