import { authInterceptor } from './auth.interceptor';
import { HttpRequest } from '@angular/common/http';

describe('authInterceptor', () => {

  it('should add token to headers if token exists', () => {

    spyOn(localStorage, 'getItem').and.returnValue('fake-token');

    const req = new HttpRequest('GET', '/test');

    const next: any = (request: any) => {
      expect(request.headers.get('Authorization')).toBe('Bearer fake-token');
      return { subscribe: () => {} };
    };

    authInterceptor(req, next);
  });

});