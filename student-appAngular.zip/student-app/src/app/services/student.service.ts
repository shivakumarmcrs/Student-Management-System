import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({ providedIn: 'root' })
export class StudentService {

  constructor(private http: HttpClient) {}

  getAll() {
    return this.http.get(`${environment.apiUrl}/student`);
  }

  getById(id: number) {
    return this.http.get(`${environment.apiUrl}/student/${id}`);
  }

  add(data: any) {
    return this.http.post(`${environment.apiUrl}/student`, data);
  }

  update(data: any) {
    return this.http.put(`${environment.apiUrl}/student`, data);
  }

  delete(id: number) {
    return this.http.delete(`${environment.apiUrl}/student/${id}`);
  }
}